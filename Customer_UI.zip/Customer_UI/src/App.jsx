import { useState } from 'react';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import { clearAccessToken, getAccessToken, login, logout, registerAccount } from './api';
import './App.css';

export default function App() {
  const [token, setToken] = useState(getAccessToken);
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const handleAuthenticate = async (formData, isRegistering) => {
    setError('');
    setNotice('');

    try {
      if (isRegistering) {
        await registerAccount(formData);
      }

      const session = await login({
        email: formData.email,
        password: formData.password,
      });
      setUser(session.user);
      setToken(session.accessToken);
    } catch (requestError) {
      setError(requestError.message);
    }
  };

  const handleLogout = async () => {
    setError('');
    setNotice('');
    try {
      await logout();
    } catch {
      setNotice('You are signed out on this device, but the server could not confirm logout.');
    } finally {
      clearAccessToken();
      setUser(null);
      setToken(null);
    }
  };

  if (token) {
    return (
      <main className="app-shell">
        <section className="panel status-panel">
          <p className="eyebrow">YOUR ACCOUNT</p>
          <h1>You’re signed in</h1>
          {user && (
            <p className="form-description">
              {user.name} · {user.email}
            </p>
          )}
          {notice && <p className="notice" role="status">{notice}</p>}
          <button className="primary-button full-width" type="button" onClick={handleLogout}>
            Log out
          </button>
        </section>
      </main>
    );
  }

  return (
    <main className="app-shell">
      {authMode === 'login' ? (
        <LoginForm
          onSubmit={handleAuthenticate}
          onShowRegister={() => {
            setError('');
            setNotice('');
            setAuthMode('register');
          }}
          error={error}
          notice={notice}
        />
      ) : (
        <RegisterForm
          onSubmit={handleAuthenticate}
          onShowLogin={() => {
            setError('');
            setNotice('');
            setAuthMode('login');
          }}
          error={error}
        />
      )}
    </main>
  );
}
