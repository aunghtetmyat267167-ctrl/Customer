import axios from 'axios';

const TOKEN_KEY = 'accessToken';
const REFRESH_TOKEN_KEY = 'refreshToken';
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
});
const refreshApi = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (cause) => {
    const originalRequest = cause.config;
    const shouldSkipRefresh = ['/auth/login', '/auth/register', '/auth/refresh-token']
      .some((path) => originalRequest?.url?.includes(path));
    const refreshToken = localStorage.getItem(REFRESH_TOKEN_KEY);

    if (
      cause.response?.status !== 401
      || !originalRequest
      || originalRequest._retry
      || shouldSkipRefresh
      || !refreshToken
    ) {
      return Promise.reject(cause);
    }

    originalRequest._retry = true;
    try {
      const response = await refreshApi.post('/auth/refresh-token', { refreshToken });
      const { accessToken, refreshToken: nextRefreshToken } = response.data.data;
      localStorage.setItem(TOKEN_KEY, accessToken);
      localStorage.setItem(REFRESH_TOKEN_KEY, nextRefreshToken);
      originalRequest.headers.Authorization = `Bearer ${accessToken}`;
      return api(originalRequest);
    } catch (refreshError) {
      clearAccessToken();
      return Promise.reject(refreshError);
    }
  },
);

async function request(config) {
  try {
    const response = await api.request(config);
    return response.data;
  } catch (cause) {
    const message = cause.response?.data?.error
      || cause.response?.data?.message
      || (cause.code === 'ERR_NETWORK'
        ? 'Cannot reach the API. Make sure the backend is running.'
        : 'The request failed.');
    const error = new Error(message, { cause });
    if (cause.response) error.status = cause.response.status;
    throw error;
  }
}

export function getAccessToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function clearAccessToken() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(REFRESH_TOKEN_KEY);
}

export async function registerAccount(data) {
  return request({ method: 'post', url: '/auth/register', data });
}

export async function login(data) {
  const result = await request({ method: 'post', url: '/auth/login', data });
  localStorage.setItem(TOKEN_KEY, result.data.accessToken);
  localStorage.setItem(REFRESH_TOKEN_KEY, result.data.refreshToken);
  return result.data;
}

export function logout() {
  return request({ method: 'post', url: '/auth/logout' });
}

export async function getMyProfile() {
  const result = await request({ method: 'get', url: '/profiles/me' });
  return result.data;
}

export async function createProfile(data) {
  const result = await request({ method: 'post', url: '/profiles', data });
  return result.data;
}

export async function updateProfile(data) {
  const result = await request({ method: 'put', url: '/profiles/me', data });
  return result.data;
}

export function deleteProfile() {
  return request({ method: 'delete', url: '/profiles/me' });
}

export default api;
