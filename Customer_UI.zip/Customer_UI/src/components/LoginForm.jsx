import { useState } from 'react';

export default function LoginForm({ onSubmit, onShowRegister, error, notice }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmit(formData, false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form className="panel auth-form" onSubmit={handleSubmit}>
      <p className="eyebrow">YOUR ACCOUNT</p>
      <h1>Welcome back</h1>
      <p className="form-description">Sign in to view and manage your profile.</p>

      {notice && <p className="notice" role="status">{notice}</p>}
      {error && <p className="error-message" role="alert">{error}</p>}

      <div className="input-group">
        <label htmlFor="login-email">Email</label>
        <input
          id="login-email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
          autoComplete="email"
          maxLength="254"
          required
        />
      </div>

      <div className="input-group">
        <label htmlFor="login-password">Password</label>
        <input
          id="login-password"
          name="password"
          type="password"
          value={formData.password}
          onChange={handleChange}
          autoComplete="current-password"
          required
        />
      </div>

      <button className="primary-button full-width" type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Please wait…' : 'Sign in'}
      </button>
      <p className="auth-switch">
        New here?{' '}
        <button type="button" className="text-button" onClick={onShowRegister}>
          Create an account
        </button>
      </p>
    </form>
  );
}
