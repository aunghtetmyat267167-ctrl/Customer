import { useState } from 'react';

export default function RegisterForm({ onSubmit, onShowLogin, error }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmit(formData, true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form className="panel auth-form" onSubmit={handleSubmit}>
      <p className="eyebrow">YOUR ACCOUNT</p>
      <h1>Create your account</h1>
      <p className="form-description">Create an account to set up your profile.</p>

      {error && <p className="error-message" role="alert">{error}</p>}

      <div className="input-group">
        <label htmlFor="register-name">Full name</label>
        <input
          id="register-name"
          name="name"
          type="text"
          value={formData.name}
          onChange={handleChange}
          autoComplete="name"
          maxLength="120"
          required
        />
      </div>

      <div className="input-group">
        <label htmlFor="register-email">Email</label>
        <input
          id="register-email"
          name="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
          autoComplete="email"
          maxLength="254"
          required
        />
      </div>

      <div className="input-group">
        <label htmlFor="register-password">Password</label>
        <input
          id="register-password"
          name="password"
          type="password"
          value={formData.password}
          onChange={handleChange}
          autoComplete="new-password"
          minLength="8"
          required
        />
        <span className="field-hint">Use at least 8 characters.</span>
      </div>

      <button className="primary-button full-width" type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Please wait…' : 'Create account'}
      </button>
      <p className="auth-switch">
        Already have an account?{' '}
        <button type="button" className="text-button" onClick={onShowLogin}>
          Sign in
        </button>
      </p>
    </form>
  );
}
